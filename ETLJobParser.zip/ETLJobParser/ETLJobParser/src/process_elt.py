"""
Parse given ETL job description in XML file
First Created: 06-AUG-2022
Last Updated:  06-AUG-2022

Author: Sachin Mittal (sachin.mittal04@gmail.com)
"""

import os
import re
import argparse
import json
import xml.etree.ElementTree as ET


def process_instance(instance):
    print(f"{instance.tag}: {instance.attrib['NAME']}")
    inst_map = {}
    if instance.attrib['TYPE'] == 'SOURCE':
        inst_map['source_table'] = instance.attrib['NAME']
    elif instance.attrib['TYPE'] == 'TARGET':
        inst_map['target_table'] = instance.attrib['NAME']
    return inst_map

def process_transformation(transformation):
    print(f"{transformation.tag}: {transformation.attrib['NAME']}")

    transformations = []
    for tfield in transformation.iter('TRANSFORMFIELD'):
        print(f"{tfield.tag}: {tfield.attrib['NAME']}")
        t_dict = {}
        if tfield.attrib['PORTTYPE'] == 'INPUT':
            t_dict['input'] = tfield.attrib['NAME']
        elif tfield.attrib['PORTTYPE'] == 'OUTPUT':
            t_dict['transformation'] = tfield.attrib['EXPRESSION']
            t_dict['output'] = tfield.attrib['NAME']
        elif tfield.attrib['PORTTYPE'] == 'INPUT/OUTPUT':
            pass
        transformations.append(t_dict)
    return transformations


def process_mappings(folder, mapping):
    print(f"{mapping.tag}: {mapping.attrib['NAME']}")

    m_dict = {}
    m_dict['folder'] = folder
    m_dict['mapping'] = mapping.attrib['NAME']

    instances = []
    for instance in mapping.iter('INSTANCE'):
        i =  process_instance(instance)
        instances.append(i)
    m_dict['instances'] = instances

    transformations = []
    for transformation in mapping.iter('TRANSFORMATION'):
        t =  process_transformation(transformation)
        transformations.append(t)
    m_dict['transformations'] = transformations

    return m_dict

def parse_etl(xml_file_path):
    """
    Parse givem xml file
    @params:
        xml_file_path (string): XML file path containing ETL job description
    @returns:
        jobs (list): A list of mappings "<source>, <transformations>, <sink>"
    """

    try:
        tree = ET.parse(xml_file_path)
        root = tree.getroot()
    except Exception as e:
        print(f"Failed to parse given file. Error: {e}")

    print('root.tag:', root.tag)

    folders = []
    for folder in root.iter('FOLDER'):
        print(f"{folder.tag}: {folder.attrib['NAME']}")

        mappings = []
        for mapping in folder.iter('MAPPING'):
            m = process_mappings(folder.attrib['NAME'], mapping)
            mappings.append(m)
        folders.append(mappings)
    #
    # jobs = [
    #     {
    #         'source' : 'source1',
    #         'transformations' : ['transofrmation1', 'transofrmation2'],
    #         'sink' : 'sink1'
    #     }
    # ]
    return folders

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    args = parser.add_argument('--xmlfile', '-x', help='XML file', required='yes')
    args = parser.parse_args()

    folders = parse_etl(args.xmlfile)

    # Dump json output to a file
    with open('etl_mapping.json', 'w') as f:
        json.dump(folders, f)

    print(f"output: {folders}")
