# ETLParser
XML PROBLEM STATEMENT


### Description
Identify how data flows from each transformation (including sql overrides if any) and is loaded into targets on column level for Informatica XML

### Prerequisite
XML File to be present on your eorking environment

## Run program
- Got to src folder
  - ```cd src```
- Run sommand
  - ``` python process_etl.py --xmlfile '<xml-file>' ```
