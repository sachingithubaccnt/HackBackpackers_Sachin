"""
Parse given sql statement and extract table names/columns etc.
First Created: 06-AUG-2022
Last Updated:  06-AUG-2022

Author: Sachin Mittal (sachin.mittal04@gmail.com)
"""

import os
import re
import argparse

def parse_outer_query_columns(columns_l):
    """
    Parse outer query columns
    @params:
        columns_l (list): string containing columns selected in outer query
    @returns:
        columns_d (dict): A dictionary mapping columns name and its table alias
    """
    cols = {col.split('.')[1]:col.split('.')[0] for col in columns_l}

    print(f'cols: {cols}')
    return cols

def get_idx(clause, q_l):
    """
    Find index of given clause in a case insensitive way
    @params:
        clause: (string): clause in upper case
        q_l: (list): List containg sql
    """
    idx = -1
    try:
        idx = q_l.index(clause.lower())
    except:
        pass

    # print(f"idx: {idx}")
    return idx

def parse_sub_query(sub_query_l):

    """
    Parse sub query to extract alias and table name
    @params:
        sub_query_l (list): list containing subquery
    @returns:
        (table_name, alias) (tuple): A tuple containing subquery table name and alias
    """

    # Look for line between FROM and WHERE clasue
    idx_f = get_idx('FROM', sub_query_l)
    idx_w = get_idx('WHERE', sub_query_l)

    tbl_name = sub_query_l[idx_f+1]

    # Last line should contain alias
    alias = sub_query_l[-1]
    alias = re.sub(r',', '', alias)

    print(f"tbl_name: {tbl_name}, alias: {alias}")
    return {alias : tbl_name}

def parse_sql(sql):
    """
    Parse given sql
    @params: sql (string) : input sql statement
    @returns: Processed output as exptected

    """
    sql = sql.split(' ')
    sql = [q.strip().lower() for q in sql if q != '']
    print(f"sql: {sql}")

    # Process outer query columns
    idx_s = get_idx('SELECT', sql)
    idx_f = get_idx('FROM', sql)
    outer_query_cols = sql[idx_s+1:idx_f]
    # print(f"outer_cuqery_cols: {outer_query_cols}")
    outer_query_cols_map = parse_outer_query_columns(outer_query_cols)
    print(f"outer_query_cols_map: {outer_query_cols_map}")

    # Process sub query
    sub_queries = sql[idx_f+1:]
    # print(f"sub_queries: {sub_queries}")

    sub_queries = [re.sub(r'.*\)', 'end', q) if q.endswith(')') else q for q in sub_queries]
    # print(f"sub_queries: {sub_queries}")

    tbl_aliases = {}
    while True:
        idx_e1 = get_idx('END', sub_queries)
        if idx_e1 == -1:
            break

        tbl_alias = parse_sub_query(sub_queries[:idx_e1+2])
        tbl_aliases.update(tbl_alias)
        # print(f"tbl_alias: {tbl_alias}")

        # Set sub_query for next iteration
        sub_queries = sub_queries[idx_e1+1:]

    # Format it as expected
    output = {}
    for q, v in outer_query_cols_map.items():
        output[q] = tbl_aliases[v]

    return output

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    args = parser.add_argument('--sql', '-s', help='SQL statement', required='yes')
    args = parser.parse_args()
    print(args)
    output = parse_sql(args.sql)
    print(f"output: {output}")
