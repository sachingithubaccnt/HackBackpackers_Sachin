#!/bin/bash

if [[ -z $(which pip3) ]]; then
   echo -e "Install pip3 and run the script again"
   echo -e "command: sudo apt-get -y install python3-pip"
   exit -1
fi

if [[ -z $(which virtualenv) ]]; then
   echo -e "Install virtualenv and run the script again"
   echo -e "command: pip3 install virtualenv"
   exit -1
fi

# Create virtual environment
echo -e "Create virtualenv at ~/venv-nextpathway"
virtualenv ~/venv-nextpathway
source ~/venv-nextpathway/bin/activate

# Install application dependencies
echo -e "Install pre-requisites"
pip3 install -r requirements.txt

echo -e "Activate virtual venv at ~/venv-nextpathway/bin/activate"

exit 0
