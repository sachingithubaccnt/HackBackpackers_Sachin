import os
import sys

# Append ../src folder in path
sys.path.append('../src')

import process_sql

def test_parse_outer_query_columns():
    sample_cols_str = f"""
        T.COL1
        T.COL2
        S.COL3
        S.COL4
    """
    print(f"sample_cols_str: {sample_cols_str}")
    expected_col_t_map = {
        'COL1' : 'T',
        'COL2' : 'T',
        'COL3' : 'S',
        'COL4' : 'S',
    }
    col_t_map = process_sql.parse_outer_query_columns(sample_cols_str)

    assert col_t_map == expected_col_t_map, f"Failed: test_parse_outer_query_columns()"

def test_parse_sub_query():
    sample_sub_query = """
        (select a, b,
        c
        FROM
        ABC.TABLE
        WHERE
        cond
        ) T
    """

    tbl_name, alias = process_sql.parse_sub_query(sample_sub_query)

    assert (tbl_name, alias) ==  ('ABC.TABLE', 'T'), f'Failed : test_parse_sub_query()'

def test_parse_sql():
    sql = """
        select T.col1, T.col2, S.col3
        S.COL4
        FROM
        (select a, b,
        c
        FROM
        ABC.TABLE
        WHERE
        cond) T,

        (select x, y,
        z
        FROM
        XYZ.TABLE
        WHERE
        cond) S

    """
    process_sql.parse_sql(sql)

if __name__ == '__main__':
    # test_parse_outer_query_columns()
    # test_parse_sub_query()
    test_parse_sql()
