# LinearProblemStatement

An SQL Statement will be passed to the Python function that trace the complete lineage and produce the originating table for each output column of the input query.

### Description

We are passing the entirre SQL query and find the Inner query first and extracting the Table name along with the ALIAS name from Subquery. For this use case we have considered two SUB Query so extracting the Table name and Aliasing respectively. Later on we are also parsing the outer Queryy to extract the column names. Finally merging the output of Inner Query along with output Query Column name and producing the output

### Prerequisite
NA

## Run program
- Got to src folder
  - ```cd src```
- Run sommand
  - ``` python process_sql.py --sql '<sql-statement>' ```
  - ``` Example:
        python process_sql.py --sql """
          select T.col1, T.col2, S.col3
            S.COL4
            FROM
            (select a, b,
            c
            FROM
            ABC.TABLE
            WHERE
            cond) T,

            (select x, y,
            z
            FROM
            XYZ.TABLE
            WHERE
            cond) S
      """
    ```
