def get_CurrentTimestamp:

    hours = utc_now("hh")

    mins = utc_now("mm")

    sec = utc_now("ss")

    curr_dt = hours + ":" + mins + ":" + sec

    return curr_dt


def get_DateFromDaysSince2:

    hours = utc_now("hh")

    mins = utc_now("mm")

    sec = utc_now("ss")

    curr_dt = hours + ":" + mins + ":" + sec

    td = timedelta(2)
    
    return curr_dt + td

def get_MinutesFromTime:

    mins = utc_now("mm")
    
    return mins


def get_Bit:

a:= TO_NUMBER('SACHIN MITTAL', 'S');
result:= '';

return(DECODE(BITAND(a,1), 0, 'success', 'fail'));

def get_abs:
var = -100
print('Absolute value  is:', abs(var))

def floor(n):
    res = int(n)
    return res if res == n or n >= 0 else res-1

def isnotnull_func:

import pandas as pd
 
d = pd.read_csv("my.csv")
 
verify_rec = pd.notnull(d["Age"])
 
d[verify_rec]

def comp_val:
a = 100
b = 10

if ( a == b ):
   print "Both values are equal"
else:
   print "Values are not equal"